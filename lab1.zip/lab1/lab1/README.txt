Matrix Math Program
Description: This program is a graphical application for performing mathematical operations on matrices.

Actions:
- Create matrices (Matrix X and Matrix Y) with customizable dimensions.
- Input values into the matrices via a grid interface.
- Perform operations such as:
    Addition
    Subtraction
    Multiplication
    Transpose
- Save and load matrices to and from files.
- View the result of operations in a separate result window.

Step 1:
Enter the number of rows and columns for Matrix X and Matrix Y.
Click the Create button.
Editable pop-up windows appear for X Matrix and Y Matrix.

Step 2:
Input values into the grid for Matrix X and Matrix Y.
Click the Save button in the editor to save the content as an openable file

Step 3:
Choose an operation from the dropdown menu:
Transpose (applies only to Matrix X).
Add or Subtract (requires the same dimensions for X and Y).
Multiply (requires the number of columns in X to match the number of rows in Y).
Execute

Step 4: View Results
A new window displays the result matrix in a grid format.

Examples:
If you input Matrix x: 2 rows with 3 columns [1,2,3],[4,5,6]
If you input Matrix y: 3 rows with 2 columns [7,8],[9,10],[11,12]
And select multiply the ouput should be: [58,64],[139,154]
