package lab1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Control
{
    private final Model model;
    private final View view;

    private double[][] xMatrix;
    private double[][] yMatrix;

    public Control() {
        model = new Model();
        view = new View();

        view.create.addActionListener(new CreateListener());
        view.execute.addActionListener(new ExecuteListener());
        view.reset.addActionListener(new ResetListener());
        view.quit.addActionListener(_ -> System.exit(0));
    }

    private class CreateListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                int xRows = Integer.parseInt(view.m1rows.getText());
                int xCols = Integer.parseInt(view.m1cols.getText());
                int yRows = Integer.parseInt(view.m2rows.getText());
                int yCols = Integer.parseInt(view.m2cols.getText());

                xMatrix = new double[xRows][xCols];
                yMatrix = new double[yRows][yCols];

                JOptionPane.showMessageDialog(view, "Matrices created successfully!");
                showMatrixEditor("X Matrix", xMatrix);
                showMatrixEditor("Y Matrix", yMatrix);
            }
            catch (NumberFormatException ex)
            {
                view.errors.setText("Invalid matrix dimensions. Please enter integers.");
            }
        }
    }

    private class ExecuteListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            try
            {
                int operation = view.operations.getSelectedIndex();
                double[][] resultMatrix;

                switch (operation)
                {
                    case 1 -> resultMatrix = model.transpose(xMatrix);
                    case 2 -> resultMatrix = model.add(true, xMatrix, yMatrix);
                    case 3 -> resultMatrix = model.add(false, xMatrix, yMatrix);
                    case 4 -> resultMatrix = model.multiply(xMatrix, yMatrix);
                    default -> throw new IllegalArgumentException("Select a valid operation.");
                }

                showResultMatrix(resultMatrix);
            }
            catch (Exception ex)
            {
                view.errors.setText("Error: " + ex.getMessage());
            }
        }
    }

    private class ResetListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            view.m1rows.setText("");
            view.m1cols.setText("");
            view.m2rows.setText("");
            view.m2cols.setText("");
            view.operations.setSelectedIndex(0);
            view.errors.setText("");
            xMatrix = null;
            yMatrix = null;
        }
    }

    private void showMatrixEditor(String title, double[][] matrix)
    {
        JFrame matrixFrame = new JFrame(title);
        matrixFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        matrixFrame.setSize(500, 400);
        matrixFrame.setLayout(new BorderLayout());
    
        JPanel gridPanel = new JPanel(new GridLayout(matrix.length, matrix[0].length));
        JTextField[][] matrixFields = new JTextField[matrix.length][matrix[0].length];
    
        // Populate grid with JTextFields initialized to the matrix values
        for (int r = 0; r < matrix.length; r++)
        {
            for (int c = 0; c < matrix[0].length; c++)
            {
                JTextField cell = new JTextField(String.valueOf(matrix[r][c]));
                matrixFields[r][c] = cell;
                gridPanel.add(cell);
            }
        }
    
        // Buttons panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
        JButton saveButton = new JButton("Save");
        JButton openButton = new JButton("Open");
        JButton clearButton = new JButton("Clear");
        JButton closeButton = new JButton("Close");
    
        // Add action listeners to the buttons
        saveButton.addActionListener(_ -> saveMatrix(matrix, matrixFields, title, matrixFrame));
        openButton.addActionListener(_ -> openMatrix(matrix, matrixFields, title, matrixFrame));
        clearButton.addActionListener(_ -> clearMatrix(matrixFields));
        closeButton.addActionListener(_ -> matrixFrame.dispose());
    
        buttonPanel.add(saveButton);
        buttonPanel.add(openButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(closeButton);
    
        // Add components to the frame
        matrixFrame.add(new JScrollPane(gridPanel), BorderLayout.CENTER);
        matrixFrame.add(buttonPanel, BorderLayout.SOUTH);
        matrixFrame.setVisible(true);
    }

    private void saveMatrix(double[][] matrix, JTextField[][] fields, String title, JFrame frame)
    {
        try
        {
            // Update the matrix with the current values from the fields
            for (int r = 0; r < matrix.length; r++)
            {
                for (int c = 0; c < matrix[0].length; c++)
                {
                    matrix[r][c] = Double.parseDouble(fields[r][c].getText());
                }
            }
    
            // Prompt for file name
            String fileName = JOptionPane.showInputDialog(frame, "Enter file name to save " + title + ":");
            if (fileName != null && !fileName.isEmpty())
            {
                model.saveFile(fileName, matrix);
                JOptionPane.showMessageDialog(frame, title + " saved to file: " + fileName);
            }
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(frame, "Error saving " + title + ": " + ex.getMessage());
        }
    }
    
    private void openMatrix(double[][] matrix, JTextField[][] fields, String title, JFrame frame)
    {
        try
        {
            // Prompt for file name
            String fileName = JOptionPane.showInputDialog(frame, "Enter file name to load " + title + ":");
            if (fileName != null && !fileName.isEmpty()) {
                double[][] loadedMatrix = model.readFile(fileName);
    
                // Check if the loaded matrix matches the current matrix dimensions
                if (loadedMatrix.length == matrix.length && loadedMatrix[0].length == matrix[0].length) {
                    // Update the matrix and fields with the loaded values
                    for (int r = 0; r < matrix.length; r++)
                    {
                        for (int c = 0; c < matrix[0].length; c++)
                        {
                            matrix[r][c] = loadedMatrix[r][c];
                            fields[r][c].setText(String.valueOf(loadedMatrix[r][c]));
                        }
                    }
                    JOptionPane.showMessageDialog(frame, title + " loaded from file: " + fileName);
                }
                else
                {
                    JOptionPane.showMessageDialog(frame, "Error: Matrix dimensions do not match.");
                }
            }
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(frame, "Error loading " + title + ": " + ex.getMessage());
        }
    }

    private void clearMatrix(JTextField[][] fields)
    {
        for (int r = 0; r < fields.length; r++) {
            for (int c = 0; c < fields[r].length; c++)
            {
                fields[r][c].setText("0");
            }
        }
    }
    
    private void showResultMatrix(double[][] matrix)
    {
        JFrame resultFrame = new JFrame("Result Matrix");
        resultFrame.setSize(500, 300);
        resultFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel gridPanel = new JPanel(new GridLayout(matrix.length, matrix[0].length));
        for (double[] row : matrix)
        {
            for (double value : row)
            {
                JLabel cell = new JLabel(String.format("%.2f", value), SwingConstants.CENTER);
                cell.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                gridPanel.add(cell);
            }
        }

        resultFrame.add(new JScrollPane(gridPanel));
        resultFrame.setVisible(true);
    }

    public static void main(String[] args)
    {
        new Control();
    }
}