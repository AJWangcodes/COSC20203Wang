package lab1;

import javax.swing.*;
import java.awt.*;

public class View extends JFrame
{
    protected JPanel p1 = new JPanel(new GridLayout(6, 2));
    protected JPanel errorsPanel = new JPanel(new BorderLayout());
    protected JTextField m1rows = new JTextField();
    protected JTextField m1cols = new JTextField();
    protected JTextField m2rows = new JTextField();
    protected JTextField m2cols = new JTextField();
    protected JComboBox<String> operations = new JComboBox<>();
    protected JButton create = new JButton("Create");
    protected JButton execute = new JButton("Execute");
    protected JButton reset = new JButton("Reset");
    protected JButton quit = new JButton("Quit");
    protected JTextField errors = new JTextField();

    public View()
    {
        setTitle("CONTROL Matrix Math Program");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 300);
        setLayout(new BorderLayout());

        operations.addItem("Select");
        operations.addItem("Transpose");
        operations.addItem("Add");
        operations.addItem("Subtract");
        operations.addItem("Multiply");

        p1.add(new JLabel("First Matrix rows/cols"));
        p1.add(new JLabel("Second Matrix rows/cols"));
        p1.add(m1rows);
        p1.add(m2rows);
        p1.add(m1cols);
        p1.add(m2cols);
        p1.add(new JLabel(""));
        p1.add(create);
        p1.add(operations);
        p1.add(execute);
        p1.add(reset);
        p1.add(quit);

        errors.setEditable(false);
        errorsPanel.add(errors, BorderLayout.CENTER);

        add(p1, BorderLayout.CENTER);
        add(errorsPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
