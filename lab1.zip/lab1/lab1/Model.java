package lab1;

import java.io.*;

public class Model
{

    public double[][] add(boolean isAddition, double[][] xarray, double[][] yarray)
    {
        int rows = xarray.length, cols = xarray[0].length;
        double[][] result = new double[rows][cols];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++)
            {
                result[r][c] = isAddition ? xarray[r][c] + yarray[r][c] : xarray[r][c] - yarray[r][c];
            }
        }
        return result;
    }

    public double[][] multiply(double[][] xarray, double[][] yarray)
    {
        int xRows = xarray.length, xCols = xarray[0].length, yCols = yarray[0].length;
        double[][] result = new double[xRows][yCols];
        for (int i = 0; i < xRows; i++)
        {
            for (int j = 0; j < yCols; j++)
            {
                for (int k = 0; k < xCols; k++)
                {
                    result[i][j] += xarray[i][k] * yarray[k][j];
                }
            }
        }
        return result;
    }

    public double[][] transpose(double[][] matrix)
    {
        int rows = matrix.length, cols = matrix[0].length;
        double[][] result = new double[cols][rows];
        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                result[c][r] = matrix[r][c];
            }
        }
        return result;
    }

    public void saveFile(String fileName, double[][] matrix) throws IOException
    {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName)))
        {
            out.writeObject(matrix);
        }
    }

    public double[][] readFile(String fileName) throws IOException, ClassNotFoundException
    {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName)))
        {
            return (double[][]) in.readObject();
        }
    }
}