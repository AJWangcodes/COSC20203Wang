# MINIBASIC Interpreter

**Name:** Avin Wang  
**Class:** COSC20203  
**Lab:** 3

## What It Does
This is a Java program with a GUI that runs a small version of BASIC (called MINIBASIC).  
You can load a `.txt` file with code, run it, and see the output in the same window.

It supports:
- Variable math (`a = 5 + 2`)
- `print` to show values
- `if (...) goto ...` for decisions
- `goto` for jumping
- `end` to stop the program

## How to Run
1. Open a terminal in the main folder (where `lab3` is)
2. Compile:

## How to Test
- Use the **Read** button to open one of the `Test*.txt` files
- Click **Run** to see it work

## In folder
- `Control.java` - main launcher
- `View.java` - builds the GUI
- `core/Model.java` - runs the code
- `core/ProgramMemory.java` - stores code lines
- `core/SymbolTable.java` - holds variables
- `core/ExpressionEvaluator.java` - solves math

