package lab3;

import lab3.core.Model;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Control.java
 * COSC20203 - Lab 3
 * Avin Wang
 * 
 * This class is part of a MINIBASIC interpreter GUI application.
 */
/**
 * Entry point for the application.
 * @param args command-line arguments
 */
public class Control extends View implements ActionListener
{
    private Model inter; 

    public static void main(String[] args)
    {
        new Control();
    }
/**
 * Constructor that sets up the control logic and button actions.
 */
    public Control()
    {
        super(); // build the GUI
        inter = new Model(codeArea); // create interpreter logic

        readButton.addActionListener(this);
        runButton.addActionListener(this);
        saveButton.addActionListener(this);
        resetButton.addActionListener(this);
    }
/**
 * Handles button click events and triggers corresponding actions.
 * @param e the event triggered by user interaction
 */
    @Override
    public void actionPerformed(ActionEvent e)
    {
        String command = e.getActionCommand();

        switch (command)
        {
            case "Read":
                inter.processRead();
                break;
            case "Run":
                inter.runProgram();
                break;
            case "Save":
                inter.processSave();
                break;
            case "Reset":
                inter.processReset();
                break;
        }
    }
}


