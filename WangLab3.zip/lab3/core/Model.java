package lab3.core;

import javax.swing.*;
import java.io.*;
import java.util.*;

/**
 * Model.java
 * COSC20203 - Lab 3
 * Avin Wang
 * 
 * This class is part of a MINIBASIC interpreter GUI application.
 */
public class Model
{
    private JTextArea codeArea;
    private SymbolTable variables = new SymbolTable();
    private ProgramMemory memory = new ProgramMemory();
    private ExpressionEvaluator evaluator = new ExpressionEvaluator(variables);
    private String startLine = null;

    public Model(JTextArea codeArea)
    {
        this.codeArea = codeArea;
    }
/**
 * Reads a BASIC program from a file and loads it into memory.
 */
    public void processRead()
    {
        codeArea.setText(""); // clear area
        JFileChooser chooser = new JFileChooser();
        int result = chooser.showOpenDialog(null);

        if (result == JFileChooser.APPROVE_OPTION)
        {
            try (BufferedReader reader = new BufferedReader(new FileReader(chooser.getSelectedFile())))
            {
                String line, prevLine = null;
                while ((line = reader.readLine()) != null)
                {
                    if (line.trim().isEmpty()) continue;
                    StringTokenizer tokenizer = new StringTokenizer(line, " ");
                    if (!tokenizer.hasMoreTokens()) continue;

                    String lineNumber = tokenizer.nextToken();
                    String instruction = line.substring(line.indexOf(" ") + 1);
                    memory.add(lineNumber, instruction);

                    if (!instruction.startsWith("//") && startLine == null)
                    {
                        startLine = lineNumber;
                    }

                    if (prevLine != null) memory.link(prevLine, lineNumber);
                    prevLine = lineNumber;

                    codeArea.append(lineNumber + " " + instruction + "\n");
                }
                codeArea.append("// Program loaded successfully\n");
            }
            catch (IOException e)
            {
                codeArea.append("ERROR reading file: " + e.getMessage() + "\n");
            }
        }
    }
/**
 * Executes the loaded BASIC program line by line.
 */
    public void runProgram()
    {
        codeArea.append("\n// Execution Output:\n");
        String current = startLine;

        while (current != null)
        {
            String code = memory.get(current);
            if (code == null) break;

            try {
                if (code.startsWith("//"))
                {
                    // Skip comment
                } else if (code.equals("end"))
                {
                    break;
                } else if (code.startsWith("print"))
                {
                    String var = code.substring(6).trim();
                    double val = variables.get(var);
                    codeArea.append(var + " = " + val + "\n");
                } else if (code.startsWith("goto"))
                {
                    current = code.substring(5).trim();
                    continue;
                } else if (code.startsWith("if"))
                {
                    int l = code.indexOf("("), r = code.indexOf(")");
                    String condition = code.substring(l + 1, r);
                    String[] parts = condition.split("=");

                    double left = variables.getOrValue(parts[0].trim());
                    double right = variables.getOrValue(parts[1].trim());

                    if (Math.abs(left - right) < 0.0001) {
                        String rest = code.substring(r + 1).trim();
                        if (rest.startsWith("goto"))
                        {
                            current = rest.substring(5).trim();
                            continue;
                        }
                    }
                }
                else if (code.contains("="))
                {
                    String[] parts = code.split("=");
                    String var = parts[0].trim();
                    String expr = parts[1].trim();
                    double result = evaluator.evaluate(expr);
                    variables.set(var, result);
                }
            }
            catch (Exception ex)
            {
                codeArea.append("Error on line " + current + ": " + ex.getMessage() + "\n");
            }

            current = memory.next(current);
        }

        codeArea.append("// Program ended\n");
    }
/**
 * Saves the content of the text area to a file.
 */
    public void processSave()
    {
        JFileChooser chooser = new JFileChooser();
        int result = chooser.showSaveDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            try (PrintWriter writer = new PrintWriter(chooser.getSelectedFile()))
            {
                writer.write(codeArea.getText());
            } catch (IOException e)
            {
                codeArea.append("ERROR saving file: " + e.getMessage() + "\n");
            }
        }
    }
/**
 * Clears all program memory and variable data.
 */
    public void processReset()
    {
        codeArea.setText("");
        variables.clear();
        memory.clear();
        startLine = null;
    }
}
