package lab3.core;

import java.util.Hashtable;

/**
 * SymbolTable.java
 * COSC20203 - Lab 3
 * Avin Wang
 * 
 * This class is part of a MINIBASIC interpreter GUI application.
 */
public class SymbolTable
{
    private Hashtable<String, Double> variables = new Hashtable<>();
/**
 * Sets the value of a variable.
 * @param name variable name
 * @param value variable value
 */ 
    public void set(String name, double value)
    {
        variables.put(name, value);
    }
/**
 * Retrieves the value of a variable.
 * @param name variable name
 * @return value of the variable, or 0.0 if not defined
 */
    public double get(String name)
    {
        return variables.getOrDefault(name, 0.0);
    }
/**
 * Returns the value of a number or looks up a variable's value.
 * @param token the token (either variable name or number)
 * @return corresponding numeric value
 */
    public double getOrValue(String token)
    {
        try
        {
            return Double.parseDouble(token);
        }
        catch (Exception e)
        {
            return get(token);
        }
    }
/**
 * Clears all stored variables.
 */
    public void clear()
    {
        variables.clear();
    }
}

