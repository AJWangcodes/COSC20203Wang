package lab3.core;

import java.util.Hashtable;

/**
 * ProgramMemory.java
 * COSC20203 - Lab 3
 * Avin Wang
 * 
 * This class is part of a MINIBASIC interpreter GUI application.
 */
public class ProgramMemory
{
    private Hashtable<String, String> code = new Hashtable<>();
    private Hashtable<String, String> nextLine = new Hashtable<>();
/**
 * Adds a line of code to memory.
 * @param lineNumber the line number as a string
 * @param instruction the code at that line
 */
    public void add(String lineNumber, String instruction)
    {
        code.put(lineNumber, instruction);
    }
/**
 * Links one line number to the next in sequence.
 * @param currentLine current line number
 * @param nextLineNumber next line number to execute
 */
    public void link(String currentLine, String nextLineNumber)
    {
        nextLine.put(currentLine, nextLineNumber);
    }
/**
 * Retrieves the code stored at a specific line.
 * @param lineNumber the line number to look up
 * @return code string at that line
 */
    public String get(String lineNumber)
    {
        return code.get(lineNumber);
    }
/**
 * Retrieves the next line number linked to the current one.
 * @param lineNumber the current line
 * @return next line number, or null if none
 */
    public String next(String lineNumber)
    {
        return nextLine.get(lineNumber);
    }
/**
 * Clears all stored code and line links.
 */
    public void clear()
    {
        code.clear();
        nextLine.clear();
    }
}
