package lab3.core;

import java.util.StringTokenizer;

/**
 * ExpressionEvaluator.java
 * COSC20203 - Lab 3
 * Avin Wang
 * 
 * This class is part of a MINIBASIC interpreter GUI application.
 */

public class ExpressionEvaluator
{
    private SymbolTable symbols;
    private StringTokenizer tokenizer;
    private String current;

    public ExpressionEvaluator(SymbolTable symbols)
    {
        this.symbols = symbols;
    }
/**
 * Evaluates an arithmetic expression and returns the result.
 * @param expr the expression string to evaluate
 * @return evaluated numeric result
 */
    public double evaluate(String expr)
    {
        tokenizer = new StringTokenizer(expr, "+-*/()", true);
        advance();
        return expression();
    }
/**
 * Advances the tokenizer to the next non-empty token.
 */
    private void advance()
    {
        while (tokenizer.hasMoreTokens())
        {
            current = tokenizer.nextToken().trim();
            if (!current.isEmpty()) break;
        }
    }
/**
 * Parses and evaluates an expression with + and - operators.
 * @return the evaluated value of the expression
 */
    private double expression()
    {
        double val = term();
        while (current != null && (current.equals("+") || current.equals("-")))
        {
            String op = current;
            advance();
            double right = term();
            val = op.equals("+") ? val + right : val - right;
        }
        return val;
    }
/**
 * Parses and evaluates a term with * and / operators.
 * @return the evaluated value of the term
 */
    private double term()
    {
        double val = factor();
        while (current != null && (current.equals("*") || current.equals("/")))
        {
            String op = current;
            advance();
            double right = factor();
            val = op.equals("*") ? val * right : val / right;
        }
        return val;
    }
/**
 * Parses and evaluates a factor (number, variable, or parenthesized expression).
 * @return the evaluated value of the factor
 */
    private double factor()
    {
        if (current.equals("("))
        {
            advance();
            double val = expression();
            if (!current.equals(")")) throw new RuntimeException("Expected ')'");
            advance();
            return val;
        }
        else
        {
            String token = current;
            advance();
            return symbols.getOrValue(token);
        }
    }
}
