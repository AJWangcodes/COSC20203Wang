package lab3;

import javax.swing.*;
import java.awt.*;

/**
 * View.java
 * COSC20203 - Lab 3
 * Avin Wang
 * 
 * This class is part of a MINIBASIC interpreter GUI application.
 */

public class View extends JFrame
{
/** Text area for program input and output */
    public JTextArea codeArea;

/** Button to load a BASIC program from file */
    public JButton readButton;

/** Button to run the currently loaded BASIC program */
    public JButton runButton;

/** Button to save the current program to file */
    public JButton saveButton;

/** Button to clear the editor and memory */
    public JButton resetButton;

    public View()
    {
        setTitle("MINIBASIC Interpreter");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        codeArea = new JTextArea();
        codeArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(codeArea);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
        readButton = new JButton("Read");
        runButton = new JButton("Run");
        saveButton = new JButton("Save");
        resetButton = new JButton("Reset");

        buttonPanel.add(readButton);
        buttonPanel.add(runButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(resetButton);

        add(buttonPanel, BorderLayout.SOUTH);
        setVisible(true);
    }
}

