package lab2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Control
{
    private final Model model;
    private final View view;

    public Control()
    {
        model = new Model();
        view = new View();

        view.encodeButton.addActionListener(new EncodeListener());
        view.decodeBinaryButton.addActionListener(new DecodeBinaryListener());
        view.decodeHexButton.addActionListener(new DecodeHexListener());
    }

    private class EncodeListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            String instruction = view.inputField.getText();
            String binary = model.encodeInstruction(instruction);
            view.binaryOutput.setText(binary);
            view.hexOutput.setText(model.binaryToHex(binary));
        }
    }

    private class DecodeBinaryListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            String binary = view.binaryOutput.getText();
            String decodedInstruction = model.decodeBinary(binary);
            view.inputField.setText(decodedInstruction);
            view.hexOutput.setText(model.binaryToHex(binary));
        }
    }
    

    private class DecodeHexListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            String hex = view.hexOutput.getText();
            String binary = model.hexToBinary(hex);
            view.binaryOutput.setText(binary);
            view.inputField.setText(model.decodeBinary(binary));
        }
    }

    public static void main(String[] args)
    {
        new Control();
    }
}
