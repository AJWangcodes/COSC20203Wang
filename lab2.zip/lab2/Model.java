package lab2;

import java.util.Map; 
import java.util.HashMap;

public class Model
{
    private final HashMap<String, String> opcodeMap;

    public Model()
    {
        //Fill HashMap in with corresponding values
        opcodeMap = new HashMap<>();
        opcodeMap.put("AND","0000");
        opcodeMap.put("EOR","0001");
        opcodeMap.put("SUB","0010");
        opcodeMap.put("RSB","0011");
        opcodeMap.put("ADD","0100");
        opcodeMap.put("ADC","0101");
        opcodeMap.put("SBC","0110");
        opcodeMap.put("RSC","0111");
        opcodeMap.put("TST","1000");
        opcodeMap.put("TEQ","1001");
        opcodeMap.put("CMP","1010");
        opcodeMap.put("CMN","1011");
        opcodeMap.put("ORR","1100");
        opcodeMap.put("MOV","1101");
        opcodeMap.put("BIC","1110");
        opcodeMap.put("MVN","1111");
    }

    //Assembly to Binary
    public String encodeInstruction(String instruction)
    {
        try
        {
            String[] parts = instruction.replace(",","").split(" ");
            if(parts.length != 4)
            {
                return "Invalid Input";
            }
            String op = parts[0].toUpperCase();
            if(!opcodeMap.containsKey(op))
            {
                return "Invalid Input";
            }
            String opcode = opcodeMap.get(op);
            String destReg =  formatRegister(parts[1]);
            String op1Reg =  formatRegister(parts[2]);
            String op2Reg =  formatRegister(parts[3]);

            return "1110" + "000" + opcode + "0" + op1Reg + destReg + "00000000" + op2Reg;

        }
        catch(Exception e)
        {
            return "Encoding Error";
        }
    }

    //Binary to Assembly
    public String decodeBinary(String binary)
    {
        if (binary.length() != 32)
        {
            return "Invalid Binary Length";
        }
        String opcode = binary.substring(4, 8);
        String op1Reg = decodeRegister(binary.substring(12, 16)); 
        String destReg = decodeRegister(binary.substring(16, 20)); 
        String op2Reg = decodeRegister(binary.substring(28, 32)); 

        String mnemo = "Unknown";
        for (Map.Entry<String, String> entry : opcodeMap.entrySet())
        {
            if (entry.getValue().equals(opcode))
            {
                mnemo = entry.getKey();
                break;
            }
        }

        return mnemo + " " + destReg + ", " + op1Reg + ", " + op2Reg;
    }

    //Binary to Hex
    public String binaryToHex(String binary)
    {
        try
        {
            long decimal = Long.parseLong(binary, 2);
            return String.format("%08X", decimal);
        }  
        catch (Exception e)
        {
        return "Invalid Hex";
        }
    }

    public String hexToBinary(String hex)
    {
        try
        {
            long decimal = Long.parseLong(hex, 16);
            return String.format("%32s", Long.toBinaryString(decimal)).replace(" ", "0");
        }
        catch (Exception e)
        {
            return "Invalid Hex";
        }
    }

    //Register  to 4-bit binary
    private String formatRegister(String reg)
    {
        return String.format("%4s", Integer.toBinaryString(Integer.parseInt(reg.substring(1)))).replace(" ", "0");
    }

    //Binary register to "R" format
    private String decodeRegister(String binary)
    {
        return "R" + Integer.parseInt(binary, 2);
    }
}
