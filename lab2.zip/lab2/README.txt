Encoding ARM Instructions
Enter an ARM instruction (e.g., ADD R1, R2, R14) in the text field.
Click "Encode".
The binary and hexadecimal representations will appear.

Decoding Binary Instructions
Paste a 32-bit binary instruction (e.g., 11100000100000010000000000001110).
Click "Decode Binary".
The decoded ARM instruction and corresponding hex value will be displayed.

Decoding Hex Instructions
Paste a hexadecimal instruction (e.g., E081000E).
Click "Decode Hex".
The corresponding binary instruction and ARM assembly will be displayed

Example:
Input:
ADD R1, R2, R14

Output:
Binary: 11100000100000010000000000001110
Hex: E081000E

Example 2: Decoding Binary
Input:
11100000100000010000000000001110

Output:
ARM Instruction: ADD R1, R2, R14
Hex: E081000E

Example 3: Decoding Hex
Input:
E081000E

Output:
Binary: 11100000100000010000000000001110
ARM Instruction: ADD R1, R2, R14