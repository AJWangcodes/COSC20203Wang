package lab2;

import javax.swing.*;
import java.awt.*;

public class View extends JFrame
{
    protected JTextField inputField;
    protected JTextField binaryOutput;
    protected JTextField hexOutput;
    protected JButton encodeButton, decodeBinaryButton, decodeHexButton;

    public View()
    {
        setTitle("Encoding ARM Instructions");
        setSize(500, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10)); 

        JPanel inputPanel = new JPanel(new FlowLayout());
        inputField = new JTextField(20);
        encodeButton = new JButton("Encode");
        inputPanel.add(new JLabel("Enter ARM Instruction:"));
        inputPanel.add(inputField);
        inputPanel.add(encodeButton);

        JPanel outputPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        binaryOutput = new JTextField(20);
        hexOutput = new JTextField(20);
        outputPanel.add(new JLabel("Binary Instruction:"));
        outputPanel.add(binaryOutput);
        outputPanel.add(new JLabel("Hex Instruction:"));
        outputPanel.add(hexOutput);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        decodeBinaryButton = new JButton("Decode Binary");
        decodeHexButton = new JButton("Decode Hex");
        buttonPanel.add(decodeBinaryButton);
        buttonPanel.add(decodeHexButton);

        add(inputPanel, BorderLayout.NORTH);
        add(outputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
